const dialog = document.getElementById('actionDialog');
const title = document.getElementById('dialogTitle');
const description = document.getElementById('dialogDescription');
const amount = document.getElementById('amountInput');
const message = document.getElementById('formMessage');
const toast = document.getElementById('toast');
let currentAction = 'deposit';

function showToast(text) {
  toast.textContent = text;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2600);
}
function openAction(action) {
  currentAction = action;
  title.textContent = action === 'deposit' ? 'Deposit Preview' : 'Withdrawal Preview';
  description.textContent = action === 'deposit'
    ? 'Enter a sample amount to preview a deposit request. No money will be moved.'
    : 'Enter a sample amount to preview a withdrawal request. No money will be moved.';
  amount.value = '';
  message.textContent = '';
  dialog.showModal();
}
document.querySelectorAll('[data-action]').forEach(el => el.addEventListener('click', e => {
  e.preventDefault();
  openAction(el.dataset.action);
}));
document.getElementById('actionForm').addEventListener('submit', e => {
  e.preventDefault();
  const value = Number(amount.value);
  if (!Number.isFinite(value) || value <= 0) {
    message.textContent = 'Please enter an amount greater than zero.';
    return;
  }
  message.textContent = `Demo ${currentAction} request for ₦${value.toLocaleString('en-NG')} previewed.`;
  showToast('Demo request preview only — no money moved.');
});
document.getElementById('copyReferral').addEventListener('click', async () => {
  const demoLink = 'https://example.com/ref/demo-user';
  try {
    await navigator.clipboard.writeText(demoLink);
    showToast('Demo referral link copied!');
  } catch {
    showToast('Demo referral link: ' + demoLink);
  }
});
document.getElementById('taskButton').addEventListener('click', e => {
  e.currentTarget.textContent = 'Done ✓';
  e.currentTarget.disabled = true;
  showToast('Task marked complete in this demo.');
});
document.getElementById('menuToggle').addEventListener('click', () => {
  document.querySelector('.sidebar').classList.toggle('open');
});
document.querySelectorAll('.side-nav a').forEach(link => link.addEventListener('click', () => {
  if (window.innerWidth <= 760) document.querySelector('.sidebar').classList.remove('open');
}));
document.getElementById('profileButton').addEventListener('click', () => showToast('Demo profile menu'));
