# VESTORA Dashboard Starter

A responsive front-end demo of the VESTORA dashboard using a black and neon-lime theme.

## Preview locally
Open `index.html` in a browser. No build step is required.

## Upload to GitHub
1. Create a repository on GitHub (for example, `vestora`).
2. Choose **Add file → Upload files**.
3. Upload `index.html`, `styles.css`, and `script.js` (and this README).
4. Commit the files.
5. In repository **Settings → Pages**, select the `main` branch and `/ (root)` folder, then save.

## Important
This is only a UI prototype. Balances, plan values, tasks, deposits, withdrawals, and referral features use sample data or front-end-only interactions. No real funds or investment returns are processed. Do not use this prototype to collect financial or identity data.

Before a real launch, design and implement secure server-side authentication, database authorization, audited ledger/transaction handling, payment-provider integration, fraud controls, privacy/security practices, and legal/regulatory review for the jurisdictions where you will operate. Avoid advertising guaranteed returns.
